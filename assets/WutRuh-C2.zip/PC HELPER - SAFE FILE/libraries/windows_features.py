# PC HELPER/libraries/windows_features.py
import os
import sys
import ctypes
import subprocess
import time

class WindowsFeatures:
    def __init__(self):
        self.user32 = ctypes.windll.user32
        self.kernel32 = ctypes.windll.kernel32
        
    def lock_inputs(self):
        """
        Locks mouse and keyboard input by blocking input devices
        """
        try:
            # Block keyboard and mouse input
            result = self.user32.BlockInput(True)
            if result:
                return True, "✅ Input devices locked successfully"
            else:
                return False, "❌ Failed to lock inputs - may require admin privileges"
        except Exception as e:
            return False, f"❌ Failed to lock inputs: {str(e)}"
    
    def unlock_inputs(self):
        """
        Unlocks mouse and keyboard input
        """
        try:
            result = self.user32.BlockInput(False)
            if result:
                return True, "✅ Input devices unlocked successfully"
            else:
                return False, "❌ Failed to unlock inputs"
        except Exception as e:
            return False, f"❌ Failed to unlock inputs: {str(e)}"
    
    def sign_out(self):
        """
        Signs out the current user
        """
        try:
            # /l = logoff
            result = subprocess.run(["shutdown", "/l"], capture_output=True, text=True, shell=True)
            if result.returncode == 0:
                return True, "✅ Sign out initiated successfully"
            else:
                return False, f"❌ Failed to sign out: {result.stderr}"
        except Exception as e:
            return False, f"❌ Failed to sign out: {str(e)}"
    
    def restart(self, timeout=30):
        """
        Restarts the PC
        
        Args:
            timeout (int): Time in seconds before restart
        """
        try:
            # /r = restart, /t = timeout, /f = force close applications
            result = subprocess.run([
                "shutdown", "/r", "/t", str(timeout), "/f"
            ], capture_output=True, text=True, shell=True)
            
            if result.returncode == 0:
                return True, f"✅ Restart initiated. PC will restart in {timeout} seconds"
            else:
                return False, f"❌ Failed to restart: {result.stderr}"
        except Exception as e:
            return False, f"❌ Failed to restart: {str(e)}"
    
    def shutdown(self, timeout=30):
        """
        Shuts down the PC
        
        Args:
            timeout (int): Time in seconds before shutdown
        """
        try:
            # /s = shutdown, /t = timeout, /f = force close applications
            result = subprocess.run([
                "shutdown", "/s", "/t", str(timeout), "/f"
            ], capture_output=True, text=True, shell=True)
            
            if result.returncode == 0:
                return True, f"✅ Shutdown initiated. PC will shut down in {timeout} seconds"
            else:
                return False, f"❌ Failed to shutdown: {result.stderr}"
        except Exception as e:
            return False, f"❌ Failed to shutdown: {str(e)}"
    
    def cancel_shutdown(self):
        """
        Cancels a pending shutdown/restart
        """
        try:
            result = subprocess.run(["shutdown", "/a"], capture_output=True, text=True, shell=True)
            if result.returncode == 0:
                return True, "✅ Pending shutdown/restart cancelled"
            else:
                return False, f"❌ Failed to cancel shutdown: {result.stderr}"
        except Exception as e:
            return False, f"❌ Failed to cancel shutdown: {str(e)}"